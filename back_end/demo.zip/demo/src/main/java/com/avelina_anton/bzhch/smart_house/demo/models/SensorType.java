package com.avelina_anton.bzhch.smart_house.demo.models;

public enum SensorType {
    TEMPERATURE,
    HUMIDITY,
    CO2,
    NOISE
}