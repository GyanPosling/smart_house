package com.avelina_anton.bzhch.smart_house.demo.models.devices;

public enum DeviceType {
    HEATER,
    AIR_CONDITIONER,
    HUMIDIFIER,
    DEHUMIDIFIER,
    VENTILATOR
}