package com.avelina_anton.bzhch.smart_house.demo.models.devices;

public enum DeviceStatus {
    ON, OFF, STAND_BY
}
